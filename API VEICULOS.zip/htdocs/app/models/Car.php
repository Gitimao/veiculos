<?php

class Car extends \HXPHP\System\Model
{
	
}